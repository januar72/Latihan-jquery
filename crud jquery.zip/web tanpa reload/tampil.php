<?php
    include("koneksi.php");
    $sql = mysqli_query($konek, "SELECT * FROM tbl_siswa");
    $result = array();
    
    while ($row = mysqli_fetch_assoc($sql)) {
        $data[] = $row;
    }

    echo json_encode(array("result" => $data));
?>