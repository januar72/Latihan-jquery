<?php 
include 'koneksi.php';

$nama =$_POST['nama'];
$kelas =$_POST['kelas'];

$simpan =mysqli_query($konek, "INSERT INTO `tbl_siswa` (`id_siswa`,`nama`,`kelas`) VALUES(null, '$nama','$kelas')");

 ?>