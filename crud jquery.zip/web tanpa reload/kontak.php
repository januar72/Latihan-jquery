<?php 
echo "ops...! maaf data ngak baik";

 ?>