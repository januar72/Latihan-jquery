<div class="card">
    <div class="card-body">
        <h5 class="card-title"><span class="badge badge-warning">Profil</span></h5>
        <p class="card-text">Ini adalah halaman Profil di load menggunakan Jquery Ajax</p>
    </div>
    <div class="container">
        <form method="post" action="" id="form-input">
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control">
            </div>
            <div class="form-group">
                <label>Kelas</label>
                <input type="text" name="kelas" class="form-control">
            </div>
            <div class="box-footer">
                <input type="submit" id="simpan" class="btn btn-primary">
            </div>
        </form>
        <div class="tampildata">
            
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#simpan').click(function(){
            var data =$('#form-input').serialize();

            $.ajax({
                type : 'POST',
                url  : 'input.php',
                data : data,
                success:function(){
                    $('tampildata').load('tampil.php');
                }
            });
        });
    });
</script>