<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
</head>
<body>
<div class="container mt-4">
	<nav class="navbar navbar-dark bg-dark mb-4">
		<a class="navbar-brand" href="">
			<img src="https://getbootstrap.com/docs/4.6/assets/brand/bootstrap-solid.svg" width="30" height="30"
                        alt="">
                    Bootstrap
		</a>
	</nav>
	<div class="row">
		<div id="menu" class="col-3">
			<ul class="list-group">
				<li class="list-group-item"><a href="beranda">Beranda</a></li>
				<li class="list-group-item"><a href="kontak">Kontak</a></li>
				<li class="list-group-item"><a href="profil">Profil</a></li>
			</ul>
		</div>
		<div class="col-9">
			<div id="content">
				<!-- isi halaman akan diload disini -->
			</div>
		</div>
	</div>
</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		// pilih kontent branda saat mengakses halaman ini
		$('#content').load('beranda.php');

		// saat href di klik maka?
		$('a').click(function(){
			// simpan isi href ke dalam variabel halaman
			var halaman =$(this).attr('href');
			// lalu kontent disi halaman sesuai pilihan
			$('#content').load(halaman + '.php');
			return false;
		})
	})
</script>
</html>