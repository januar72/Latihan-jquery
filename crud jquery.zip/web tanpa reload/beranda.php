<div class="card">
    <div class="card-body">
        <h5 class="card-title"><span class="badge badge-primary">Beranda</span></h5>
        <p class="card-text">Ini adalah halaman beranda di load menggunakan Jquery Ajax</p>
    </div>
    <div class="container">
    	<table class="table table-bordered">
    		<thead>
    			<tr>
    				<th>Nama</th>
    				<th>Kelas</th>
    			</tr>
    		</thead>
    		<tbody id="tampildata">
    		</tbody>
    	</table>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script type="text/javascript">
    	$(document).ready(function(){
    		selesai();
    	});
    	function selesai(){
    		setTimeout(function(){
    			update();
    			selesai();
    		}, 200);
    	}

    	function update(){
    		$.getJSON('tampil.php', function(data){
    			$('#tampildata').empty();
    			var no =1;
    			$.each(data.result, function(){
    				$("#tampildata").append("<tr></td>" + (no++) + "</td><td>"+ this['nama']+ "</td><td>" + this['kelas'] + "</td></tr>");
    			});
    		});
    	}
    </script>
</div>